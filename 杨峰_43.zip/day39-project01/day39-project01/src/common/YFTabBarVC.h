//
//  YFTabBarVC.h
//  day39-project01
//
//  Created by apple on 15/11/21.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFTabBarVC : UITabBarController
@property (nonatomic,strong)UIView *bottom;
@property (nonatomic,strong)UIView *subbot;
-(void)hideSubbot;
-(void)hideBottom:(BOOL)hide;
@end

@interface NoHlBtn : UIButton

@end