
//
//  YFNavVC.m
//  day39-project01
//
//  Created by apple on 15/11/22.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import "YFNavVC.h"
#import "YFTabBarVC.h"

@interface YFNavVC ()

@end

@implementation YFNavVC

- (void)viewDidLoad {
    [super viewDidLoad];

}

-(void)showViewController:(UIViewController *)vc sender:(id)sender{
    [super showViewController:vc sender:sender];
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [UIViewController setVC:self];
}
@end
