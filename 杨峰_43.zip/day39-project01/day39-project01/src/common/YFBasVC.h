//
//  YFBasVC.h
//  day39-project01
//
//  Created by apple on 15/11/21.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFBasVC : UIViewController

-(void)dismLoadV;
-(void)showLoadVWithMes:(NSString *)mes;
-(void)showToast:(NSString *)mes;

@end
