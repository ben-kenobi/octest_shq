
//
//  YFHomeM.m
//  day39-project01
//
//  Created by apple on 15/11/22.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import "YFHomeM.h"
#import "YFFocusList.h"

@implementation YFHomeM

-(NSString *)description{

    return iFormatStr(@"{@\"YFHomeM\":%@}",self.focus );
}

@end
