//
//  YFCDV1CellTableViewCell.h
//  day39-project01
//
//  Created by apple on 15/11/28.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFCDV1Cell : UITableViewCell

@property (nonatomic,strong)NSDictionary *dict;


@end
