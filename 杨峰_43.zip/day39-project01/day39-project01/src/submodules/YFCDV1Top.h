//
//  YFCDV1Top.h
//  day39-project01
//
//  Created by apple on 15/11/28.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFCDV1Top : UIView
@property (nonatomic,strong)UIButton *area;
@property (nonatomic,strong)UISearchBar *sb;
@property (nonatomic,strong)UIButton *search;
@end
