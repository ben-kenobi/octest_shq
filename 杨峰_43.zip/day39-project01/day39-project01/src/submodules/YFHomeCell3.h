//
//  YFHomeCell3.h
//  day39-project01
//
//  Created by apple on 15/11/24.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DSGuessModel;
@interface YFHomeCell3 : UICollectionViewCell

@property (nonatomic,strong)DSGuessModel *m;

@end
