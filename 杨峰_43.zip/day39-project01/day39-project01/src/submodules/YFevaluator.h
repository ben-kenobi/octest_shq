//
//  YFevaluator.h
//  day27-network
//
//  Created by apple on 15/11/2.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFevaluator : UIView

@property (nonatomic,assign)NSInteger count;
@property (nonatomic,assign)CGFloat unit;
@property (nonatomic,strong)UIColor *color;
@property (nonatomic,assign)CGFloat percent;
@property (nonatomic,assign)BOOL shadow;
@end
