//
//  YFFocusList.m
//  day39-project01
//
//  Created by apple on 15/11/22.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import "YFFocusList.h"

@implementation YFFocusList

-(NSString *)description{
    return [self.list descriptionWithLocale:0];
}
@end
