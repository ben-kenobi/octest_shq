//
//  YFUserHeader.h
//  day39-project01
//
//  Created by apple on 15/11/26.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFUserHeader : UIView
@property (nonatomic,strong)UIButton *icon;
@property (nonatomic,strong)UILabel *name;
@property (nonatomic,strong)UIButton *myorder;
@end
