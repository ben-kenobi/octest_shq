//
//  YFGoodCell2.h
//  day39-project01
//
//  Created by apple on 15/11/27.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFGoodCell2 : UITableViewCell
@property (nonatomic,strong)NSDictionary *dict;
@property (nonatomic,strong)UIButton *dist;
@property (nonatomic,strong)UIButton *share;
@end
