//
//  YFLoginTF.h
//  day39-project01
//
//  Created by apple on 15/11/24.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFLoginTF : UITextField

+(instancetype)tfWithFrame:(CGRect)frame img:(UIImage *)img ph:(NSString *)ph;

@end
