//
//  YFCDV2HV.h
//  day39-project01
//
//  Created by apple on 15/11/30.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFCDV2HV : UITableViewHeaderFooterView
@property (nonatomic,strong)UIButton *btn;
@property (nonatomic,strong)NSDictionary *dict;
@end
