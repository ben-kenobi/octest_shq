//
//  YFHomeCell2.h
//  day39-project01
//
//  Created by apple on 15/11/24.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DSFamousModel;
@interface YFHomeCell2 : UICollectionViewCell
@property (nonatomic,strong)DSFamousModel *m;
@end
