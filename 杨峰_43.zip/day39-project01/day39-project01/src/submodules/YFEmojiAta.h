//
//  YFEmojiAta.h
//  day35-map
//
//  Created by apple on 15/11/13.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFEmojiAta : NSTextAttachment
@property (nonatomic,copy)NSString *name;
+(NSString *)strFromAstr:(NSAttributedString *)astr;
@end
