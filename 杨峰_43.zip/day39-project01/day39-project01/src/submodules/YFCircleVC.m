//
//  YFCircleVC.m
//  day39-project01
//
//  Created by apple on 15/11/21.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import "YFCircleVC.h"
#import "YFGoodTV.h"
@interface YFCircleVC ()
@end

@implementation YFCircleVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
}


@end
