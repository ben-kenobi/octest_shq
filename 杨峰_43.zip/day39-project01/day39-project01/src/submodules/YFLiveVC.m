//
//  YFLiveVC.m
//  day39-project01
//
//  Created by apple on 15/11/21.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import "YFLiveVC.h"

@interface YFLiveVC ()

@end

@implementation YFLiveVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor randColor]];
}


@end
