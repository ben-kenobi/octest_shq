//
//  YFCircleDetailVC.h
//  day39-project01
//
//  Created by apple on 15/11/28.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import "YFBasNavVC.h"
@class DSGroupModel;

@interface YFCircleDetailVC : YFBasNavVC

@property (nonatomic,strong)DSGroupModel *m;

@end
