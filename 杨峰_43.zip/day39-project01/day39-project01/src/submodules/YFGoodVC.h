//
//  YFGoodVC.h
//  day39-project01
//
//  Created by apple on 15/11/27.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YFBasNavVC.h"

@interface YFGoodVC : YFBasNavVC

@property (nonatomic,strong)NSDictionary *shopinfo;
@property (nonatomic,strong)NSDictionary *goodinfo;

@end
