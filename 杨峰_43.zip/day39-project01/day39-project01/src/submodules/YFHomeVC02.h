//
//  YFHomeVC02.h
//  day39-project01
//
//  Created by apple on 15/11/24.
//  Copyright (c) 2015年 yf. All rights reserved.
//

#import "YFBasNavVC.h"

@interface YFHomeVC02 : YFBasNavVC

@end
