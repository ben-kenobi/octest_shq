//
//  MD5.h
//  QDLesson
//
//  Created by Ricky on 15/6/9.
//  Copyright (c) 2015年 Ricky. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MD5 : NSObject
+ (NSString *)MD5Encrypt:(NSString *)str;
@end
