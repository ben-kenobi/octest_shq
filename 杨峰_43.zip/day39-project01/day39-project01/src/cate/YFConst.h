

#import <Foundation/Foundation.h>

#define ScaleTopMargin 35
#define ScaleRight .14

#define iGlobalGreen iColor(33, 197, 180,1)

#define iGlobalBlue iColor(63,169,248,1)




extern NSString *const ANOTI;
extern NSString *const SEARCHHISFILE;
extern NSString *const GUIDENOTI;
extern NSString *const DSAPPID;
extern NSString *const DSIDENTIFIER;
extern NSString *const HOMESCROLLIDEN;