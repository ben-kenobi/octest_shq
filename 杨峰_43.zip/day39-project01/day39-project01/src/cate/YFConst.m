
#import "YFConst.h"

NSString *const ANOTI = @"ANOTI";

NSString *const SEARCHHISFILE = @"searchHistory.plist";

NSString *const GUIDENOTI = @"GUIDE2MAINNOTI";

NSString *const DSAPPID=@"1001";
NSString *const DSIDENTIFIER=@"5bV9JhaMn2GJ5MZe";
NSString *const HOMESCROLLIDEN=@"HOMESCROLLIDEN";