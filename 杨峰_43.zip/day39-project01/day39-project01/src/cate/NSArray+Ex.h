//
//  NSArray+Ex.h
//  day27-network
//
//  Created by apple on 15/10/30.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Ex)

@end
@interface NSDictionary (Ex)

@end