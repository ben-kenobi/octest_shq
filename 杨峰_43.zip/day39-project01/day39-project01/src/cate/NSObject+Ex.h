//
//  NSObject+Ex.h
//  day30-neteasenews
//
//  Created by apple on 15/11/7.
//  Copyright (c) 2015年 itheima. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Ex)


+(instancetype)setDict:(NSDictionary *)dict;

@end
